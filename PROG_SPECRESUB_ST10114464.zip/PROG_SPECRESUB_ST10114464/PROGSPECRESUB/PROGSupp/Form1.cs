﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using System.Media;
using System.Diagnostics.Eventing.Reader;
namespace PROGSupp
{

   

    public partial class Form1 : Form
    {
        private DeweyDecimalQuiz quiz;
        private int timerCountdown;
        private const int TimerInterval = 1000;
        private int score; //Added score variable
        //Added music for when the application begins
        private SoundPlayer backgroundMusicPlayer;
        private Timer greenFlashTimer;
        private Timer redFlashTimer;


        public Form1()//DeweyDecimalQuiz quiz
        {
            InitializeComponent();

            

            //Initialise green flashing timer
            greenFlashTimer = new Timer();
            greenFlashTimer.Interval = 500; // FLash every 500 milliseconds
            greenFlashTimer.Tick += GreenFlashTimer_Tick;
            greenFlashTimer.Start();
            picGreenSquare.BackColor = Color.Green;

            //Initialise red flashing timer
            redFlashTimer = new Timer();
            redFlashTimer.Interval = 500;
            redFlashTimer.Tick += RedFlashTimer_Tick;
            redFlashTimer.Start();
            picRedSquare.BackColor = Color.Red;

            quiz = new DeweyDecimalQuiz();
            timerCountdown = 30;
            timer1.Interval = TimerInterval;
            timer1.Tick += timer1_Tick_1;
            score = 0; // Initialise score
            //PlayMusic("musicGame.mp3");

            //Initialise and configure the backround music player
            //backgroundMusicPlayer = new SoundPlayer("589_full_paphos_0145_preview.wav");
            backgroundMusicPlayer = new SoundPlayer("musicGame.wav");
            backgroundMusicPlayer.Load();
            backgroundMusicPlayer.PlayLooping();
        }
       /* public static void PlayMusic(string filepath)
        {
            //SoundPlayer musicPlayer = new SoundPlayer();
           // musicPlayer.SoundLocation = filepath;
           // musicPlayer.Play();
        }
       */

        private void btnStart_Click(object sender, EventArgs e)
        {
            //Call a method to start the quiz2
            StartQuiz();
            timer1.Start();
        }

        private void StartQuiz()
        {
            //Stop both flashing timers
            greenFlashTimer.Stop();
            redFlashTimer.Stop();

            //Quiz logic goes here
            DisplayNextQuestion();
        }

        private void DisplayNextQuestion()
        {
            var questionData = quiz.GetRandomThirdLevelEntry();

            if (questionData != null) 
            {
                lblDisplayQ.Text = questionData.Description;

                var options = quiz.GetRandomTopLevelOptions(questionData.Category);

                optionsListBox.Items.Clear();
                optionsListBox.Items.AddRange(options.ToArray());

                /*
                //Get a random third-level entry from the data
                DeweyDecimalData questionData = quiz.GetRandomThirdLevelEntry();

                //Display the descripotion in the label
                lblDisplayQ.Text = questionData.Description;

                //Get four top-level options, including the correct one
                List<string> options = quiz.GetRandomTopLevelOptions(questionData.CallNumber);
                */
                //Display the options in numerical oder by call number
                optionsListBox.Items.Clear();
                optionsListBox.Items.AddRange(options.ToArray());

                lblScore.Text = $"Score: {score}";
            }
            else
            {
                MessageBox.Show("No data found");
            }

        }

        private void btnCheckAns_Click(object sender, EventArgs e)
        {
            if (optionsListBox.SelectedItem != null)
            {


                //Check the selected answer
                string selectedAnswer = optionsListBox.SelectedItem?.ToString();
                bool isCorrect = quiz.CheckAnswer(selectedAnswer);

                if (isCorrect)
                {
                    //If correct, show green square
                    picGreenSquare.Visible = true;
                    picRedSquare.Visible = false;
                    //If correct increase score
                    score += 10;
                    //Display score
                    lblScore.Text = $"Score: {score}";
                    //If correct, display the next question
                    DisplayNextQuestion();
                }
                else
                {
                    //If incorrect, show red square
                    picRedSquare.Visible = true;
                    picGreenSquare.Visible = false;
                    //If incorrect, indicate this and ask the next question
                    MessageBox.Show("Incorrect! Please try again");
                }
                
            }
            else
            {
                //Display a message if no item is selected
                MessageBox.Show("please select and answer before checking.");
            }
            Task.Delay(1000).ContinueWith(_ =>
            {
                //Access UI controls on the UI thread using invoke
                Invoke((MethodInvoker)delegate
                {
                    picGreenSquare.Visible = false;
                    picRedSquare.Visible = false;
                });
            });
        }
      

       /* private void Timer1_Tick(Object sender, EventArgs e)
        {
            
            
        }
       */
       private void GreenFlashTimer_Tick(object sender, EventArgs e)
        {
            picGreenSquare.Visible = !picGreenSquare.Visible;
        }

        private void RedFlashTimer_Tick(object sender, EventArgs e)
        {
            picRedSquare.Visible = !picRedSquare.Visible;
        }

        private void ResetTimer()
        {
            //Resets the timer countdown
            timerCountdown = 30;

        }
        //-----------------------------------------------------------------------------
        public class DeweyTreeNode
        {
            public string Category { get; set; }
            public string Description { get; set; }

            public List<DeweyTreeNode> Subcategories { get; set; } = new List<DeweyTreeNode>();


        }

        public class DeweyDecimalQuiz
        {
            
            private DeweyTreeNode root;
                

            public DeweyDecimalQuiz()
            {
                //Initialise the tree with a root node 
                root = new DeweyTreeNode
                {

                    Category = "000",
                    Description = "Generalaties"
                };

                //Load data into the tree from the file
                LoadDataFromFile("DeweyData.txt");

            }

            private void LoadDataFromFile(string filePath)
            {
                try
                {
                    foreach (var line in File.ReadLines(filePath))
                    {
                        var parts = line.Split(' ');
                        if (parts.Length >= 2)
                        {
                            AddToTree(root, parts[0], string.Join(" ", parts.Skip(1)));
              
                        }
                    }
                }

                catch (Exception ex)
                {
                    Console.WriteLine($"Error Loading data: {ex.Message}");

                }
            }
            /*
            public DeweyDecimalData GetRandomThirdLevelEntry()
            {
                var thirdLevelEntries = data.Where(entry => entry.CallNumber.Count(c => c == '.') == 2).ToList();
                return thirdLevelEntries[random.Next(thirdLevelEntries.Count)];

            }
            */

            private void AddToTree(DeweyTreeNode parent, string category, string description)
            {
                var newNode = new DeweyTreeNode { Category = category, Description = description };
                parent.Subcategories.Add(newNode);
            }

            public DeweyTreeNode GetRandomThirdLevelEntry()
            {
                var thirdLevelEntries = FlattenTree(root).Where(node => node.Category.Count(c => c == '.') == 3).ToList();

                if(thirdLevelEntries.Count > 0)
                {
                    var random = new Random();
                    return thirdLevelEntries[random.Next(thirdLevelEntries.Count)];

                }
                else
                {
                    //Handle the case where no third level entries are found
                    //Can return null or throw an exception
                    //throw new InvalidOperationException("No third-Level entries found");
                    return null;
                }
            }

            private IEnumerable<DeweyTreeNode> FlattenTree(DeweyTreeNode node)
            {
                yield return node;

                foreach ( var subcategory in node.Subcategories.SelectMany(FlattenTree))
                {
                    yield return subcategory;
                }
            }

            public List<string> GetRandomTopLevelOptions(string correctCategory)
            {
                var topLevelOptions = FlattenTree(root).Where(node => node.Category.Length == 3).ToList();
                topLevelOptions = topLevelOptions.Where(node => node.Category != correctCategory.Substring(0, 3)).ToList();
                topLevelOptions = topLevelOptions.OrderBy(node => node.Category).ToList();

                var options = new List<string>();
                options.Add(correctCategory.Substring(0, 3) + " " + GetDescriptionByCategory(correctCategory.Substring(0, 3)));

                for (int i = 0; i < 3; i++)
                {
                    options.Add(topLevelOptions[i].Category + " " + topLevelOptions[i].Description);

                }
                return options.OrderBy(option => option).ToList();
            }

            public bool CheckAnswer(string selectedAnswer)
            {
                return selectedAnswer?.StartsWith("000") == true; //Adjust the condition as needed

            }

            private string GetDescriptionByCategory(string category)
            {

                return FlattenTree(root).FirstOrDefault(node => node.Category == category )?.Description ?? "";


            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            //Exit button for the user to close th program
            Application.Exit();
        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            //UPdate the time to display and handle the count down
            timerCountdown--;
            lblTimer.Text = $"Time: {timerCountdown} seconds";

            if (timerCountdown <= 0)
            {
                //Handle timeout
                timer1.Stop();
                MessageBox.Show("Times up, Quiz end");

                //Reset timer for now question
                ResetTimer();
            }
        }
        //------------------------------------------------------------------------------------------------------------------
    }
}
