Dewey Decimal Quiz Application
Overview
The Dewey Decimal Quiz Application is a simple quiz game designed to help users learn and test their knowledge of Dewey Decimal Classification (DDC) system. The application presents users with questions based on the DDC, allowing them to select answers and receive immediate feedback on their correctness.

Features
1. Randomized quiz questions based on Dewey Decimal Classification.
2. Multiple-choice answers to select from.
3. Immediate feedback on the correctness of selected answers.
4. Timer countdown to add an element of challenge.
5. Visual cues for correct and incorrect answers.
6. Background music to enhance the user experience.
7. Getting Started

Prerequisites

1. Windows operating system.
.NET Framework installed (minimum version XYZ).

Installation

1. Clone the repository to your local machine.
2. Open the solution file (PROGSupp.sln) in Visual Studio.
3. Build the solution to restore NuGet packages and compile the application.
4. Run the application by clicking the "Start" button in Visual Studio or by navigating to the compiled executable file.

Usage

1. Upon launching the application, users are greeted with an option to start the quiz.
2. Clicking the "Start Quiz" button initiates the quiz, presenting the user with a question and multiple-choice answers.
3. Users select an answer and click the "Check Answer" button to receive immediate feedback on its correctness.
4. The application displays visual cues (green or red squares) to indicate correct or incorrect answers respectively.
5. A timer countdown adds a time constraint, making the quiz more challenging.
6. Users can exit the application by clicking the "Exit" button.

ST10114464 Jean-Luc Le Roux
