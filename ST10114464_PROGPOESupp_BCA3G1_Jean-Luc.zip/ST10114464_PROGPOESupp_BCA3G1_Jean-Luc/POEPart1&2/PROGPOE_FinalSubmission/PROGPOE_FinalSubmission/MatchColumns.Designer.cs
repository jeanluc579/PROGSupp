﻿
namespace PROGPOE_FinalSubmission
{
    partial class MatchColumns
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCallNum = new System.Windows.Forms.Label();
            this.lblDescrip = new System.Windows.Forms.Label();
            this.txtCallNumAnswer = new System.Windows.Forms.TextBox();
            this.txtDescripAnswer = new System.Windows.Forms.TextBox();
            this.btnNewQues = new System.Windows.Forms.Button();
            this.btnSubAnswer = new System.Windows.Forms.Button();
            this.btnEndGame = new System.Windows.Forms.Button();
            this.lblScore = new System.Windows.Forms.Label();
            this.btnQuit = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblCallNum
            // 
            this.lblCallNum.AutoSize = true;
            this.lblCallNum.Location = new System.Drawing.Point(61, 105);
            this.lblCallNum.Name = "lblCallNum";
            this.lblCallNum.Size = new System.Drawing.Size(64, 13);
            this.lblCallNum.TabIndex = 0;
            this.lblCallNum.Text = "Call Number";
            this.lblCallNum.Click += new System.EventHandler(this.lblCallNum_Click);
            // 
            // lblDescrip
            // 
            this.lblDescrip.AutoSize = true;
            this.lblDescrip.Location = new System.Drawing.Point(61, 180);
            this.lblDescrip.Name = "lblDescrip";
            this.lblDescrip.Size = new System.Drawing.Size(60, 13);
            this.lblDescrip.TabIndex = 1;
            this.lblDescrip.Text = "Description";
            this.lblDescrip.Click += new System.EventHandler(this.lblDescrip_Click);
            // 
            // txtCallNumAnswer
            // 
            this.txtCallNumAnswer.Location = new System.Drawing.Point(320, 105);
            this.txtCallNumAnswer.Name = "txtCallNumAnswer";
            this.txtCallNumAnswer.Size = new System.Drawing.Size(148, 20);
            this.txtCallNumAnswer.TabIndex = 2;
            this.txtCallNumAnswer.TextChanged += new System.EventHandler(this.txtCallNumAnswer_TextChanged);
            // 
            // txtDescripAnswer
            // 
            this.txtDescripAnswer.Location = new System.Drawing.Point(320, 173);
            this.txtDescripAnswer.Name = "txtDescripAnswer";
            this.txtDescripAnswer.Size = new System.Drawing.Size(148, 20);
            this.txtDescripAnswer.TabIndex = 3;
            this.txtDescripAnswer.TextChanged += new System.EventHandler(this.txtDescripAnswer_TextChanged);
            // 
            // btnNewQues
            // 
            this.btnNewQues.Location = new System.Drawing.Point(92, 270);
            this.btnNewQues.Name = "btnNewQues";
            this.btnNewQues.Size = new System.Drawing.Size(103, 34);
            this.btnNewQues.TabIndex = 4;
            this.btnNewQues.Text = "Next question";
            this.btnNewQues.UseVisualStyleBackColor = true;
            this.btnNewQues.Click += new System.EventHandler(this.btnNewQues_Click);
            // 
            // btnSubAnswer
            // 
            this.btnSubAnswer.Location = new System.Drawing.Point(251, 270);
            this.btnSubAnswer.Name = "btnSubAnswer";
            this.btnSubAnswer.Size = new System.Drawing.Size(93, 34);
            this.btnSubAnswer.TabIndex = 5;
            this.btnSubAnswer.Text = "Submit Answer";
            this.btnSubAnswer.UseVisualStyleBackColor = true;
            this.btnSubAnswer.Click += new System.EventHandler(this.btnSubAnswer_Click);
            // 
            // btnEndGame
            // 
            this.btnEndGame.Location = new System.Drawing.Point(396, 270);
            this.btnEndGame.Name = "btnEndGame";
            this.btnEndGame.Size = new System.Drawing.Size(101, 34);
            this.btnEndGame.TabIndex = 6;
            this.btnEndGame.Text = "END GAME";
            this.btnEndGame.UseVisualStyleBackColor = true;
            this.btnEndGame.Click += new System.EventHandler(this.btnEndGame_Click);
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.Location = new System.Drawing.Point(199, 37);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(47, 13);
            this.lblScore.TabIndex = 7;
            this.lblScore.Text = "SCORE:";
            this.lblScore.Click += new System.EventHandler(this.lblScore_Click);
            // 
            // btnQuit
            // 
            this.btnQuit.Location = new System.Drawing.Point(574, 270);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(101, 34);
            this.btnQuit.TabIndex = 8;
            this.btnQuit.Text = "QUIT";
            this.btnQuit.UseVisualStyleBackColor = true;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(336, 350);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(88, 39);
            this.btnBack.TabIndex = 9;
            this.btnBack.Text = "BACK";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // MatchColumns
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.btnEndGame);
            this.Controls.Add(this.btnSubAnswer);
            this.Controls.Add(this.btnNewQues);
            this.Controls.Add(this.txtDescripAnswer);
            this.Controls.Add(this.txtCallNumAnswer);
            this.Controls.Add(this.lblDescrip);
            this.Controls.Add(this.lblCallNum);
            this.Name = "MatchColumns";
            this.Text = "MatchColumns";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCallNum;
        private System.Windows.Forms.Label lblDescrip;
        private System.Windows.Forms.TextBox txtCallNumAnswer;
        private System.Windows.Forms.TextBox txtDescripAnswer;
        private System.Windows.Forms.Button btnNewQues;
        private System.Windows.Forms.Button btnSubAnswer;
        private System.Windows.Forms.Button btnEndGame;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.Button btnBack;
    }
}