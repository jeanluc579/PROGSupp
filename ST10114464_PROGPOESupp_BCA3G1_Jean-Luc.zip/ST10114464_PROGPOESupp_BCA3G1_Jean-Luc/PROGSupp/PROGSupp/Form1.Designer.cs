﻿
namespace PROGSupp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblDisplayQ = new System.Windows.Forms.Label();
            this.btnStart = new System.Windows.Forms.Button();
            this.optionsListBox = new System.Windows.Forms.ListBox();
            this.btnCheckAns = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblTimer = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lblScore = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblDisplayQ
            // 
            this.lblDisplayQ.AutoSize = true;
            this.lblDisplayQ.Location = new System.Drawing.Point(391, 107);
            this.lblDisplayQ.Name = "lblDisplayQ";
            this.lblDisplayQ.Size = new System.Drawing.Size(86, 13);
            this.lblDisplayQ.TabIndex = 0;
            this.lblDisplayQ.Text = "Display Question";
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(300, 186);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(118, 23);
            this.btnStart.TabIndex = 1;
            this.btnStart.Text = "START QUIZ";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // optionsListBox
            // 
            this.optionsListBox.FormattingEnabled = true;
            this.optionsListBox.Location = new System.Drawing.Point(76, 107);
            this.optionsListBox.Name = "optionsListBox";
            this.optionsListBox.Size = new System.Drawing.Size(169, 199);
            this.optionsListBox.TabIndex = 2;
            // 
            // btnCheckAns
            // 
            this.btnCheckAns.Location = new System.Drawing.Point(456, 186);
            this.btnCheckAns.Name = "btnCheckAns";
            this.btnCheckAns.Size = new System.Drawing.Size(118, 23);
            this.btnCheckAns.TabIndex = 3;
            this.btnCheckAns.Text = "Check answer";
            this.btnCheckAns.UseVisualStyleBackColor = true;
            this.btnCheckAns.Click += new System.EventHandler(this.btnCheckAns_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(402, 290);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 4;
            this.btnExit.Text = "EXIT";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblTimer
            // 
            this.lblTimer.AutoSize = true;
            this.lblTimer.Location = new System.Drawing.Point(76, 29);
            this.lblTimer.Name = "lblTimer";
            this.lblTimer.Size = new System.Drawing.Size(36, 13);
            this.lblTimer.TabIndex = 5;
            this.lblTimer.Text = "Timer:";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick_1);
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.Location = new System.Drawing.Point(271, 29);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(38, 13);
            this.lblScore.TabIndex = 6;
            this.lblScore.Text = "Score:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.lblTimer);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnCheckAns);
            this.Controls.Add(this.optionsListBox);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.lblDisplayQ);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDisplayQ;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.ListBox optionsListBox;
        private System.Windows.Forms.Button btnCheckAns;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblTimer;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblScore;
    }
}

