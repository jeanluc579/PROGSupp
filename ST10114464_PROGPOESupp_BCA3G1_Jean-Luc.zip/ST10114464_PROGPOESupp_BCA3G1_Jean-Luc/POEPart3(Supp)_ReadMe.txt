# Dewey Decimal Quiz Application

## Description

The Dewey Decimal Quiz Application is a learning tool designed to help users understand and navigate the Dewey Decimal Classification system. It includes a quiz that drills users deeper into the hierarchy until they find the correct answers.

## Features

- Finding Call Numbers Task
- Quiz functionality with random selection of third-level entries
- Display of four top-level options with descriptions and call numbers
- Gamification features: Timer and Score tracking
- Tree structure to store Dewey Decimal classification data in memory

## Getting Started

### Prerequisites

- .NET Framework (Version X.X.X)
- Visual Studio (Optional)

### Installation

1. Clone the repository or download the ZIP file.
   ```bash
   git clone https://github.com/jeanluc579/your-repository.git

## Compiling

Build the solution in your IDE

## Running

Run the application

## Usage

Choose the "Finding Call Numbers" task from the main menu.

Answer the quiz questions to test your knowledge of the Dewey Decimal Classification system.

For each question:

A third-level entry will be randomly selected and displayed with its description.

Four top-level options will be presented, including the correct answer and three incorrect ones.

Select the correct option to progress to the next level or answer the next question.

Incorrect selections will be indicated, and the next question will be presented.

The Timer will count down from 30 seconds. If time runs out, the quiz ends, and your score is displayed.

The Score is calculated based on correct answers, and it is displayed after each question.

Enjoy learning about the Dewey Decimal Classification system!
## Folder Structure

PROGSupp: Main application folder
DeweyData.txt: File containing Dewey Decimal classification data
Form1.cs: Main form containing application logic